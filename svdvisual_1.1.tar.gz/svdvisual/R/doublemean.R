doublemean <-
function(x){
   columnmean(x)+rowmean(x)-overallmean(x)
}
